#-*- coding: utf-8 -*-
import xlrd
import io

#open thai dict
filename = "thaidict3.txt"
with io.open(filename, 'r', encoding = 'utf-8') as f:
	text = f.read()

#open thai word frequency excel with 5000 words compiled by Chula university
workbook = xlrd.open_workbook('freq-5000.xls')
sheet = workbook.sheet_by_index(0)
colword = []
colfreq = []
for row in range(2,4940):
	colword.append(sheet.cell(row,1).value)
	colfreq.append(sheet.cell(row,2).value)

#check how many words in file
def file_len(fname):
	with open(fname) as f:
		for i, l in enumerate(f):
			pass 
	return i+1

#check if word is in dictionary
def indict(word):
	textsplit = text.split()
	size = len(textsplit)
	i = 0
	while i < size:
		s = textsplit[i]
		if s == word:
			return True
		i+=1
	return False


#check if word is in freq-5000 or thaidict3 
def contains(word):
	size = len(colword)
	i = 0
	while i < size:
		s = colword[i]
		if s == word:
			return 0
		i+=1

	textsplit = text.split()
	size = len(textsplit)
	i = 0
	while i < size:
		s = textsplit[i]
		if s == word:
			return 1
		i+=1
	return 2


#get the probability of the word
def getprob(word):
	#print("this is the word")
	#print(word)
	if(contains(word) == 0):
		size = len(colword)
		i = 0
		while i < size:
			s = colword[i]
			if s == word:
				return (colfreq[i]/  30210076 )*1000000
			i+=1
	elif(contains(word) == 1):
		return 1
	elif(contains(word) == 2): 
		return 0

#score of input string
def score(string):
	resultsplit = string.split("|")
	score = 0
	for i in range(0,len(resultsplit)):
		score += getprob(resultsplit[i])
	return score

#break down input
def wordbreak(string):
  wordUtil(string,"")
           
def wordUtil(string,result):
	n = len(string)
	for i in range(1,n+1):
	    prefix = string[0:i]
	    #print(prefix)
	    if indict(prefix):
	      if i == n:
	        result += prefix
	        print(result)
	        print "score :  ", score(result)
	      #print("2 : ",string[i:n])
	      wordUtil(string[i:n],result + prefix + "|")


# We use Chula's 5000 most frequent words to calculate likelihood of sentence
# many flaws in this because the word bank includes not real words
# like characters in the alphabet, so the scoring is skewed 
# also the most frequent word does not mean that it is correct in that context

# Problem: sometimes the of the same sentence is calculated twice, this happens because 
# we are using 2 word banks

#s is input word
s = u"มีใครเห็นกฎหมายชุดใหม่ในสภาหรือยังค่ะ"
wordbreak(s)


