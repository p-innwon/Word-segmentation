For website, we are using django.
Before you run the server, you need to change dir of excel and dictionary in wordsegment\wsegment\views.py
Line 31: filename = "C:/.../wordsegment/wsegment/thaidict3.txt"
And
Line 36: workbook = xlrd.open_workbook('C:/.../wordsegment/wsegment/freq-5000.xls')