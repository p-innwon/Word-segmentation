from django.apps import AppConfig


class WsegmentConfig(AppConfig):
    name = 'wsegment'
