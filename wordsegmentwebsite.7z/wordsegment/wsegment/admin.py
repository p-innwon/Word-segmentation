from django.contrib import admin


from .models import Word

admin.site.register(Word)
# Register your models here.
