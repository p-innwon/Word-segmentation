from django import forms

class sentenceForm(forms.Form):
    sentence = forms.CharField(label='Your sentence', max_length=100)
